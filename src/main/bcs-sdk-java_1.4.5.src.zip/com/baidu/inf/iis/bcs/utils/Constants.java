/*   */ package com.baidu.inf.iis.bcs.utils;
/*   */ 
/*   */ public class Constants
/*   */ {
/* 9 */   public static String DEFAULT_ENCODING = "UTF-8";
/*   */   public static final String NULL_VERSION_ID = "null";
/*   */   public static final int KB = 1024;
/*   */   public static final int MB = 1048576;
/*   */   public static final long GB = 1073741824L;
/*   */ }

/* Location:           C:\Users\i058959\Downloads\homekits\Baidu-BCS-SDK-Java-1.4.5\bcs-sdk-java_1.4.5.jar
 * Qualified Name:     com.baidu.inf.iis.bcs.utils.Constants
 * JD-Core Version:    0.6.2
 */