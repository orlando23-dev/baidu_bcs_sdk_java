/*    */ package com.baidu.inf.iis.bcs.model;
/*    */ 
/*    */ public class BCSClientException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public BCSClientException(String paramString)
/*    */   {
/* 17 */     super(paramString);
/*    */   }
/*    */ 
/*    */   public BCSClientException(String paramString, Throwable paramThrowable) {
/* 21 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }

/* Location:           C:\Users\i058959\Downloads\homekits\Baidu-BCS-SDK-Java-1.4.5\bcs-sdk-java_1.4.5.jar
 * Qualified Name:     com.baidu.inf.iis.bcs.model.BCSClientException
 * JD-Core Version:    0.6.2
 */