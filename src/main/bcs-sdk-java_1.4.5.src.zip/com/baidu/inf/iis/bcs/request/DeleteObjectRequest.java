/*    */ package com.baidu.inf.iis.bcs.request;
/*    */ 
/*    */ import com.baidu.inf.iis.bcs.http.HttpMethodName;
/*    */ 
/*    */ public class DeleteObjectRequest extends BaiduBCSRequest
/*    */ {
/*    */   public DeleteObjectRequest(String paramString1, String paramString2)
/*    */   {
/* 13 */     super(paramString1, paramString2, HttpMethodName.DELETE);
/*    */   }
/*    */ }

/* Location:           C:\Users\i058959\Downloads\homekits\Baidu-BCS-SDK-Java-1.4.5\bcs-sdk-java_1.4.5.jar
 * Qualified Name:     com.baidu.inf.iis.bcs.request.DeleteObjectRequest
 * JD-Core Version:    0.6.2
 */